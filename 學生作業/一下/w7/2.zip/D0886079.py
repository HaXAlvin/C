# -*- coding: utf-8 -*-
"""
Created on Sun May 17 23:20:55 2020

@author: aszx4
"""

pkm0 = {'name' : '妙蛙種子', 'type' : 'grass', 'CP' : 100}
pkm1 = {'name' : '小火龍', 'type' : 'fire', 'CP' : 100}
pkm2 = {'name' : '傑尼龜', 'type' : 'water', 'CP' : 100}
list_pkm = [pkm0, pkm1, pkm2]
print('編號0')
print('名字 :', pkm0['name'])
print('屬性 :', pkm0['type'])
print('CP值 :', pkm0['CP'])
print('編號1')
print('名字 :', pkm1['name'])
print('屬性 :', pkm1['type'])
print('CP值 :', pkm1['CP'])
print('編號2')
print('名字 :', pkm2['name'])
print('屬性 :', pkm2['type'])
print('CP值 :', pkm2['CP'])