#include <stdio.h>
#include <stdlib.h>

int main()
{
    for(int i=1;i<=3;i++){
       for(int j=0;j<4;j++){
           for(int k=3-i;k>0;k--){
               printf(" ");
       }
       for(int k=0;k<i;k++){
           printf("*");
       }
       for(int k=1;k<i;k++){
           printf("*");
       }

       for(int k=3-i;k>0;k--){
           printf(" ");
       }
       printf(" ");

     }
      printf("\n");
  }

     for(int i=2;i>=1;i--){
       for(int j=0;j<4;j++){
           for(int k=3-i;k>0;k--){
               printf(" ");
       }
       for(int k=0;k<i;k++){
           printf("*");
       }
       for(int k=1;k<i;k++){
           printf("*");
       }

       for(int k=3-i;k>0;k--){
           printf(" ");
       }
       printf(" ");
     }
      printf("\n");
  }
    for(int i=1;i<=3;i++){
       for(int j=0;j<4;j++){
           for(int k=3-i;k>0;k--){
               printf(" ");
       }
       for(int k=0;k<i;k++){
           printf("*");
       }
       for(int k=1;k<i;k++){
           printf("*");
       }

       for(int k=3-i;k>0;k--){
           printf(" ");
       }
       printf(" ");
     }
      printf("\n");
  }
     for(int i=2;i>=1;i--){
       for(int j=0;j<4;j++){
           for(int k=3-i;k>0;k--){
               printf(" ");
       }
       for(int k=0;k<i;k++){
           printf("*");
       }
       for(int k=1;k<i;k++){
           printf("*");
       }

       for(int k=3-i;k>0;k--){
           printf(" ");
       }
       printf(" ");
     }
      printf("\n");
  }
    for(int i=1;i<=3;i++){
       for(int j=0;j<4;j++){
           for(int k=3-i;k>0;k--){
               printf(" ");
       }
       for(int k=0;k<i;k++){
           printf("*");
       }
       for(int k=1;k<i;k++){
           printf("*");
       }

       for(int k=3-i;k>0;k--){
           printf(" ");
       }
       printf(" ");
     }
      printf("\n");
  }
     for(int i=2;i>=1;i--){
       for(int j=0;j<4;j++){
           for(int k=3-i;k>0;k--){
               printf(" ");
       }
       for(int k=0;k<i;k++){
           printf("*");
       }
       for(int k=1;k<i;k++){
           printf("*");
       }

       for(int k=3-i;k>0;k--){
           printf(" ");
       }
       printf(" ");
     }
      printf("\n");
  }
}











