#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){
    int a[4];
    int ans;
    int n,f,g,z;
    while(scanf("%s",a[4])!=EOF)    //�@�@���
        printf(">>\t");                 .
        for(int i=0;i<=4;i++)           .
        if(a[4]!=n){                    .
           printf("INPUT ERROR");
        }                               .
        else if(a[4]!=f){
            printf("INPUT ERROR");      .
        }
        else if(a[4]!=g){               .
            printf("INPUT ERROR");
        }
        else if(a[4]!=z){
            printf("INPUT ERROR");
        }
        else if(ans!=n){
            printf("nAmB");
        }
        else if(ans=f){
            printf("nAmB");
        }
        else if(ans!=g){
            printf("nAmB");
        }
        else if(ans!=z){
            printf("nAmB");
        }
        else if(n=n){
            printf("nAmB");
        }
        else if(n=f){
            printf("nAmB");
        }
        else if(n=g){
            printf("nAmB");
        }
        else if(n=z){
            printf("nAmB");
        }
        else if(f=n){
            printf("nAmB");
        }
        else if(f=f){
            printf("nAmB");
        }
        else if(f=g){
            printf("nAmB");
        }
        else if(f=z){
            printf("nAmB");
        }
        else if(g=n){
            printf("nAmB");
        }
        else if(g=f){
            printf("nAmB");
        }
        else if(g=g){
            printf("nAmB");
        }
        else if(g=z){
            printf("nAmB");
        }
        else if(z=n){
            printf("nAmB");
        }
        else if(z=f){
            printf("nAmB");
        }
        else if(z=g){
            printf("nAmB");
        }
        else if(z=z){
            printf("nAmB");
        }
        else if(���T���׬۲�){
        }
        else
            printf("YOU WIN");



}
